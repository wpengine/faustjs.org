export default function Page() {
  return <p>This is a Page page</p>;
}
