export default function Single() {
  return <p>This is a Single page</p>;
}
