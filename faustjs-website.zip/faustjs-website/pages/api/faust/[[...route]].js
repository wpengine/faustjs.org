import '../../../faust.config';
import { apiRouter } from '@faustwp/core';

export default apiRouter;
