export default function Footer() {
  return (
    <div>
      <p>Footer goes here</p>
    </div>
  );
}
