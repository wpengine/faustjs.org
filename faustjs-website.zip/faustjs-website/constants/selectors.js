export const MAIN_CONTENT_ID = 'main-content';
