export const PRIMARY_LOCATION = "PRIMARY";
export const FOOTER_LOCATION = "FOOTER_1";
