"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/[...wordpressNode]";
exports.ids = ["pages/[...wordpressNode]"];
exports.modules = {

/***/ "./pages/[...wordpressNode].js":
/*!*************************************!*\
  !*** ./pages/[...wordpressNode].js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Page),\n/* harmony export */   \"getStaticPaths\": () => (/* binding */ getStaticPaths),\n/* harmony export */   \"getStaticProps\": () => (/* binding */ getStaticProps)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _faustwp_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @faustwp/core */ \"@faustwp/core\");\n/* harmony import */ var _faustwp_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_faustwp_core__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction Page(props) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_faustwp_core__WEBPACK_IMPORTED_MODULE_1__.WordPressTemplate, {\n        ...props\n    }, void 0, false, {\n        fileName: \"/Users/kellen.mace/Sites/faustjs.org/pages/[...wordpressNode].js\",\n        lineNumber: 4,\n        columnNumber: 10\n    }, this);\n}\nfunction getStaticProps(ctx) {\n    return (0,_faustwp_core__WEBPACK_IMPORTED_MODULE_1__.getWordPressProps)({\n        ctx\n    });\n}\nasync function getStaticPaths() {\n    return {\n        paths: [],\n        fallback: \"blocking\"\n    };\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9bLi4ud29yZHByZXNzTm9kZV0uanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBO0FBQXFFO0FBRXRELFNBQVNFLElBQUksQ0FBQ0MsS0FBSyxFQUFFO0lBQ2xDLHFCQUFPLDhEQUFDRiw0REFBaUI7UUFBRSxHQUFHRSxLQUFLOzs7OztZQUFJLENBQUM7QUFDMUMsQ0FBQztBQUVNLFNBQVNDLGNBQWMsQ0FBQ0MsR0FBRyxFQUFFO0lBQ2xDLE9BQU9MLGdFQUFpQixDQUFDO1FBQUVLLEdBQUc7S0FBRSxDQUFDLENBQUM7QUFDcEMsQ0FBQztBQUVNLGVBQWVDLGNBQWMsR0FBRztJQUNyQyxPQUFPO1FBQ0xDLEtBQUssRUFBRSxFQUFFO1FBQ1RDLFFBQVEsRUFBRSxVQUFVO0tBQ3JCLENBQUM7QUFDSixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vQGZhdXN0d3AvZ2V0dGluZy1zdGFydGVkLWV4YW1wbGUvLi9wYWdlcy9bLi4ud29yZHByZXNzTm9kZV0uanM/MzVmYSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBnZXRXb3JkUHJlc3NQcm9wcywgV29yZFByZXNzVGVtcGxhdGUgfSBmcm9tIFwiQGZhdXN0d3AvY29yZVwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQYWdlKHByb3BzKSB7XG4gIHJldHVybiA8V29yZFByZXNzVGVtcGxhdGUgey4uLnByb3BzfSAvPjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldFN0YXRpY1Byb3BzKGN0eCkge1xuICByZXR1cm4gZ2V0V29yZFByZXNzUHJvcHMoeyBjdHggfSk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTdGF0aWNQYXRocygpIHtcbiAgcmV0dXJuIHtcbiAgICBwYXRoczogW10sXG4gICAgZmFsbGJhY2s6IFwiYmxvY2tpbmdcIixcbiAgfTtcbn1cbiJdLCJuYW1lcyI6WyJnZXRXb3JkUHJlc3NQcm9wcyIsIldvcmRQcmVzc1RlbXBsYXRlIiwiUGFnZSIsInByb3BzIiwiZ2V0U3RhdGljUHJvcHMiLCJjdHgiLCJnZXRTdGF0aWNQYXRocyIsInBhdGhzIiwiZmFsbGJhY2siXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/[...wordpressNode].js\n");

/***/ }),

/***/ "@faustwp/core":
/*!********************************!*\
  !*** external "@faustwp/core" ***!
  \********************************/
/***/ ((module) => {

module.exports = require("@faustwp/core");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/[...wordpressNode].js"));
module.exports = __webpack_exports__;

})();